const refreshFrequency = false; // ms

const render = ({ output }) => {
    return (
    <div class='screen'>
    <link rel="stylesheet" type="text/css" href="/pecan/style.css" />
    <div class='pecanbackground'></div>
    </div>
    );
}
export { refreshFrequency, render };
